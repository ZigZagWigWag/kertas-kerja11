<!--Membuat sambungan ke db-->
<?php
$conn = mysqli_connect('localhost','root','','eVaksin'); //kod untuk sambung dengan databse dilengkapkan

//sila lengkapkan kod aturcara

?>

